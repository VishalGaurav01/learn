# monitoring-module

![Architecture](https://github.com/Harsh-Srivastav123/monitoring-module/blob/main/diagram-export-3-31-2025-11_47_57-PM.png)
